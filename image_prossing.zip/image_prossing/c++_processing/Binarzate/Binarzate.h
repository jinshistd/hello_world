#ifndef __BINARZATE_H
#define __BINARZATE_H

#include <opencv2/opencv.hpp>
#include <string>
#include <iostream>
#include <cassert>

using namespace std;
using namespace cv;

#undef MAX
    #define MAX(a,b,c) ((a)>(b)?((a)>(c)?(a):(c)):((b)>(c)?(b):(c)))

#undef MIN
    #define MIN(a,b,c) ((a)<(b)?((a)<(c)?(a):(c)):((b)<(c)?(b):(c)))

/*图像二值化类定义*/
class Binarzate
{
    public:
        void Gary_Img(Mat src,Mat dst);
        void Binary_Img(Mat src,Mat dst);//二值化函数
    private:
        int offsets = 0;//通道数
        int cols = 0;//列数
        int rows = 0;//行数
        float IpSrc = 127;//二值化阈值
};

#endif