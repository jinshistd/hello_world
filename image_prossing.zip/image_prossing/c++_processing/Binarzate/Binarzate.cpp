/**************************
 * data：2020/6/20
 * author：shijin
 * 功能1：RGB转为灰度图像
 * 功能2：灰度图像二值化
**************************/
#include "Binarzate.h"

Binarzate binarzate;

/*************************
 * 函数功能：将图像转换为灰度图像
 * 返回值：NOON
 * 入口参数：输入输出图像
 * data：2020/6/20
*************************/
void Binarzate::Gary_Img(Mat src,Mat dst)
{
    binarzate.offsets = src.channels();
    binarzate.rows = src.rows;
    binarzate.cols = src.cols;

    string GARY_TITLE = "GARY_TITLE_IMG";

    dst = Mat::zeros(src.size(),src.type());

    for(int row = 0;row < binarzate.rows;row++)
    {
        const Vec3b* current = src.ptr<Vec3b>(row);
        Vec3b* output = dst.ptr<Vec3b>(row);

        for(int col = 0;col < binarzate.cols;col++)
        {
            //只针对RGB通道图像
            int b = src.at<Vec3b>(row,col)[0];
            int g = src.at<Vec3b>(row,col)[1];
            int r = src.at<Vec3b>(row,col)[2];
            
            float Gary = r*0.299 + g*0.587 + b*0.114;
            
            dst.at<Vec3b>(row,col)[0] = Gary;
            dst.at<Vec3b>(row,col)[1] = Gary;
            dst.at<Vec3b>(row,col)[2] = Gary;
        }
    }
    namedWindow(GARY_TITLE,WINDOW_AUTOSIZE);
    imshow(GARY_TITLE,dst);
    cout<<"channels:"<<dst.channels()<<endl;
}

/********************************
 * 函数功能：将灰度图像转换为二值化图像
 * 返回值：NOON
 * 入口参数：输入图像为转换后的输出图像
 * 输出图像为二值化图像 
 * data：2020/6/20
********************************/
void Binarzate::Binary_Img(Mat src,Mat dst)
{
    binarzate.offsets = src.channels();
    binarzate.rows = src.rows;
    binarzate.cols = src.cols;

    string Binary_title = "Binary_title_img";

    dst = Mat::zeros(src.size(),src.type());

    for(int row = 0;row < binarzate.rows;row++)
    {
        for(int col = 0;col < binarzate.cols;col++)
        {
            int b = src.at<Vec3b>(row,col)[0];
            
            if(b > binarzate.IpSrc)//如果像素值大于阈值
            {
                dst.at<Vec3b>(row,col)[0] = 255;
                dst.at<Vec3b>(row,col)[1] = 255;
                dst.at<Vec3b>(row,col)[2] = 255;
            }
            else
            {
                /* code */
                dst.at<Vec3b>(row,col)[0] = 0;
                dst.at<Vec3b>(row,col)[1] = 0;
                dst.at<Vec3b>(row,col)[2] = 0;
            }    
        }
    }
    namedWindow(Binary_title,WINDOW_AUTOSIZE);
    imshow(Binary_title,dst);
}

