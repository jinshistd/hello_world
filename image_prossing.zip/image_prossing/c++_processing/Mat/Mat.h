#ifndef __MAT_H
#define __MAT_H

#include <opencv2/opencv.hpp>
#include <string>

//error
/*#ifdef __cplusplus
    extern "C"
#endif*/

using namespace std;
using namespace cv;

//图像掩模操作
//计算算法：I(i,j) = 5*I(i,j) - [I(i-1,j)+I(i+1,j)+I(i,j-1)+I(i,j+1)]
void Mask(Mat src,Mat dst);

#endif