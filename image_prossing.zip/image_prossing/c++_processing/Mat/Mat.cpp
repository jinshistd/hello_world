#include "Mat.h"

//添加会出现重复定义的错误
/*#ifdef __cplusplus
    extern "CPP"
#endif*/

/*
*函数实现：掩模操作
*daor:20/6/17
*author:shijin
*function:Mask(Mat,Mat)
*入口参数:输入矩阵和输出矩阵(图像)
*返回值：无
*/
void Mask(Mat src,Mat dst)
{
    int offsets = src.channels();//获取图像的通道数，一般RGB图像通道数目为3，而灰度图像数为1
    int cols = (src.cols - 1)*offsets;
    int rows = src.rows;

    string Mat_output = "Mat_output";
    //初始化dst目标图像的大小
    /*多种方式可以进行初始化
    *克隆：clone
    *Mat传参数初始化...
    */
    dst = Mat::zeros(src.size(),src.type());
    //图像二维矩阵操作
    //需要从边缘像素的旁边一个开始处理
    //否则会出现内存泄漏(原因：数组越界)
    //计算算法：I(i,j) = 5*I(i,j) - [I(i-1,j)+I(i+1,j)+I(i,j-1)+I(i,j+1)]
    for(int row = 1;row < (rows-1);row++)
    {
        //通过地址访问当前点上下左右四个点的像素值，并方便后续操作
        const uchar* current = src.ptr<uchar>(row);//当前行的像素位置
        const uchar* previous = src.ptr<uchar>(row+1);//基于当前行的上一行
        const uchar* next = src.ptr<uchar>(row-1);//基于当前行的下一行
        //设置输出图形像素位置，方便操作
        uchar* output = dst.ptr<uchar>(row);

        for(int col = offsets;col < cols;col++)
        {
            /*output[col] = 5*current[col] - (current[col-offsets] + current[col+offsets]+\
            previous[col] + next[col]); */
            output[col] = current[cols-col-1];
        }
    }
    //显示
    namedWindow(Mat_output,WINDOW_AUTOSIZE);//WINDOW_AUTOSIZE根据当前图像大小自动显示，不可调整显示大小
    imshow(Mat_output,dst);
}


