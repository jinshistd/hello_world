#ifndef __GEOME_H
#define __GEIME_H

#include <string>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <cassert>

//name space
using namespace std;
using namespace cv;

//图像左右镜像
//图像上下镜像
//类名 Geome
//可以根据多种组合排列陈不同程度的旋转
class Geome
{
    public:
        void y_mirror(Mat src,Mat dst);
        void x_mirror(Mat src,Mat dst);
    private:
        int offsets = 0;
        int cols = 0;
        int rows = 0;
};

#endif