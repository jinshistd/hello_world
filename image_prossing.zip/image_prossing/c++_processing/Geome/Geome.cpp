#include "Geome.h"

Geome geome;
/****************************************
 * 函数功能：实现图像左右镜像
 * data：2020/6/20
 * author：shijin
 * 入口参数：输入图像和输出图像
 * 函数原型：void y_mirror(Mat src,Mat dst)
 * 拓展：实现RGB图像镜像
 * 实现具体思路：像素点位置关于y轴镜像转换
*****************************************/
void Geome::y_mirror(Mat src,Mat dst)
{
    geome.offsets = src.channels();//通道值，灰度图像为1，RGB图像为3
    geome.rows = src.rows;//图像矩阵大小获取
    geome.cols = src.cols;

    cout<<"rows = "<<geome.rows<<endl;
    cout<<"cols = "<<geome.cols<<endl;

    string y_mirror_title = "y_mirror_img";
    /*初始化输出图像，让其具有输入图像同样的大小及类型*/
    dst = Mat::zeros(src.size(),src.type());
    
    /*调试信息*/
    cout<<"channels:"<<src.channels()<<endl;

    //debug:问题出在类成员变量访问方式上面
    for(int row = 0;row < geome.rows;row++)
    {
        const Vec3b* current = src.ptr<Vec3b>(row);  
        Vec3b* output = dst.ptr<Vec3b>(row);

        for(int col = 0;col < geome.cols;col++)
        {
            if(src.channels() == 1)//单通道图像
            {
                //output[col] = current[geome.cols-col-1];
                int gray = src.at<uchar>(row,col);
                dst.at<uchar>(row,geome.cols-col) = gray;
            }
            
            else if(src.channels() == 3)//RGB图像
            {
                int b = src.at<Vec3b>(row,col)[0];
                int g = src.at<Vec3b>(row,col)[1];
                int r = src.at<Vec3b>(row,col)[2];

                dst.at<Vec3b>(row,geome.cols-col)[0] = b;
                dst.at<Vec3b>(row,geome.cols-col)[1] = g;
                dst.at<Vec3b>(row,geome.cols-col)[2] = r;
                //output[col] = current[geome.cols-col-1];
            }
        }
    }
    //输出图像，显示
    namedWindow(y_mirror_title,WINDOW_AUTOSIZE);
    imshow(y_mirror_title,dst);
}

/****************************************
 * 函数功能：实现图像上下镜像
 * data：2020/6/20
 * author：shijin
 * 入口参数：输入图像和输出图像
 * 函数原型：void x_mirror(Mat src,Mat dst)
 * 拓展：实现RGB图像镜像
 * 实现具体思路：像素点位置关于x轴镜像转换
*****************************************/
void Geome::x_mirror(Mat src,Mat dst)
{
    geome.offsets = src.channels();//通道值，灰度图像为1，RGB图像为3
    geome.rows = src.rows;//图像矩阵大小获取
    geome.cols = src.cols;

    cout<<"rows = "<<geome.rows<<endl;
    cout<<"cols = "<<geome.cols<<endl;

    string y_mirror_title = "y_mirror_img";
    /*初始化输出图像，让其具有输入图像同样的大小及类型*/
    dst = Mat::zeros(src.size(),src.type());
    
    /*调试信息*/
    cout<<"channels:"<<src.channels()<<endl;

    //debug:问题出在类成员变量访问方式上面
    for(int row = 0;row < geome.rows;row++)
    {
        const Vec3b* current = src.ptr<Vec3b>(row);  
        Vec3b* output = dst.ptr<Vec3b>(row);

        for(int col = 0;col < geome.cols;col++)
        {
            if(src.channels() == 1)//单通道图像
            {
                //output[col] = current[geome.cols-col-1];
                int gray = src.at<uchar>(row,col);
                dst.at<uchar>(geome.rows-row,col) = gray;
            }
            
            else if(src.channels() == 3)//RGB图像
            {
                int b = src.at<Vec3b>(row,col)[0];
                int g = src.at<Vec3b>(row,col)[1];
                int r = src.at<Vec3b>(row,col)[2];

                dst.at<Vec3b>(geome.rows-row,col)[0] = b;
                dst.at<Vec3b>(geome.rows-row,col)[1] = g;
                dst.at<Vec3b>(geome.rows-row,col)[2] = r;
                //output[col] = current[geome.cols-col-1];
            }
        }
    }
    //输出图像，显示
    namedWindow(y_mirror_title,WINDOW_AUTOSIZE);
    imshow(y_mirror_title,dst);
}


