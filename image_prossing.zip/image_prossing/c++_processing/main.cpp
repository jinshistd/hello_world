#include <iostream>
#include <opencv2/opencv.hpp>
#include "Mat.h"
#include "Filter.h"
#include "Geome.h"
#include "Binarzate.h"


/*
* 完成目标：图像掩模操作
* 待完成目标：均值滤波 -
* >中值滤波 -
* >膨胀:局部最大值 -
* >腐蚀 -
* >开运算 -
* >闭运算 - 
* >水平翻转 -
* >垂直翻转 -
*/
using namespace std;
using namespace cv;

int main(void)
{
    Mat src,dst,dst_img,dst_bin,dest,dest_img;

    Filter filter;
    Geome geome;
    Binarzate binarzate;
    //图像读入
    src = imread("/home/shijin/image_prossing/c++_processing/image/lena.png",1);
    //判断是否找到图像
    if(!src.data)
    {
	   cout<<"open fail!"<<endl;
	   return -1;
    }
    
    dst = Mat::zeros(src.size(),src.type());
    dst_img = Mat::zeros(src.size(),src.type());
    dest = Mat::zeros(src.size(),src.type());
    dest_img = Mat::zeros(src.size(),src.type());

    //显示输入图像
    namedWindow("input_img", WINDOW_AUTOSIZE);  // 创建图像显示窗口
    imshow("input_img", src);  // 显示图像img
    
    //灰度图像
    binarzate.Gary_Img(src,dst);
    binarzate.Binary_Img(dst,dst_img);


    /*filter.Erosion(dst_img,dest);
    filter.Dilate(dest,dest_img);

    bitwise_not(dest_img,dest_img);
    //blur(dest_img,dest_img,Size(3,3),Point(-1,-1));
    namedWindow("bit_not",WINDOW_AUTOSIZE);
    imshow("bit_not",dest_img);*/

    //API处理
    //1、转换为灰度图像
    /*cvtColor(src,dst,COLOR_BGR2GRAY);
    namedWindow("gray_img",WINDOW_AUTOSIZE);
    imshow("gray_img",dst);
    //2、二值化
    adaptiveThreshold(~dst,dst_img,255,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,15,-2);
    namedWindow("binary_img",WINDOW_AUTOSIZE);
    imshow("binary_img",dst_img);
    //3、提取水平结构元素
    Mat hilne = getStructuringElement(MORPH_RECT,Size(src.cols/16,1),Point(-1,-1));
    //4、提取垂直方向元素
    Mat vline = getStructuringElement(MORPH_RECT,Size(1,src.cols/16),Point(-1,-1));
    //5、提取矩形结构元素
    Mat kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));

    //oepning option
    erode(dst_img,dest,kernel);
    dilate(dest,dest_img,kernel);

    bitwise_not(dest_img,dest_img);

    namedWindow("dest_img",WINDOW_AUTOSIZE);
    imshow("dest_img",dest_img);*/

    waitKey(0);  // 等待任意按键按下
    return 0; 
    //cout<<"hello,world!"<<endl;
}


