#ifndef __FILTER_H
#define __FILTER_H

#include <opencv2/opencv.hpp>
#include <string>
#include <iostream>

//命名空间定义
using namespace std;//input，output
using namespace cv;//opencv

//改写代码
//重新封装
class Filter
{
    public:
        //函数定义
        //均值滤波，取周围9个像素点求平均值，代替当前点的像素点值
        //算法原理：取周围9个像素点的值，计算average
        //函数声明
        void Average_Filter(Mat src,Mat dst);
        //函数声明
        //中值滤波
        //算法原理：取周围像素点中的中间值作为当前像素点的值
        void Median_Filter(Mat src,Mat dst);

        //冒泡排序算法
        void bubble_sort(int arr[],int n);

        //膨胀算法
        void Dilate(Mat src,Mat dst);

        //腐蚀算法
        void Erosion(Mat src,Mat dst);
};

#endif