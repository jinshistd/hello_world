/******************************
* data:2020/6/18
* auother:shijin
* function:filter
* program:c++
*******************************/

//头文件包含
#include "Filter.h"

Filter filter;//类数据定义

//像素点枚举变量
#undef Point
enum Point
{  
    point_00 = 0,
    point_01,
    point_02,
    point_03,
    point_04,
    point_05,
    point_06,
    point_07,
    point_08
};

/******************************
 * 函数功能：均值滤波
******************************/
void Filter::Average_Filter(Mat src,Mat dst)
{
    int offsets = src.channels();
    int cols = (src.cols-1)*offsets;
    int rows = src.rows;

    string Aerage_Filter_Title = "Aerage_Filter_Img";

    //初始化目标图像，让其具有跟输入图像同样的属性
    dst = Mat::zeros(src.size(),src.type());
    for(int row = 1;row < (rows-1);row++)
    {
        const uchar* current = src.ptr<uchar>(row);
        const uchar* previous = src.ptr<uchar>(row+1);
        const uchar* next = src.ptr<uchar>(row-1);

        //像素点位置初始化
        uchar* output = dst.ptr<uchar>(row);

        for(int col = offsets;col < cols;col++)
        {
            output[col] = (current[col+offsets] + \
            current[col] + current[col+offsets] + previous[col] + \
            previous[col-offsets] + previous[col+offsets] + next[col+offsets]+\
            next[col] + next[col+offsets])/9;
        }
    }
    
    namedWindow(Aerage_Filter_Title,WINDOW_AUTOSIZE);
    imshow(Aerage_Filter_Title,dst);
}

/*********************************
 * 函数功能：中值滤波
 * 返回值：NOON
 * data:2020/6/18
 * 入口参数：
 * src：输入图像
 * _dst：输出图像
 * 实现目标：9个点的中值滤波
 * Author：shijin
*********************************/ 
void Filter::Median_Filter(Mat src,Mat dst)
{
    int offsets = src.channels();
    int cols = (src.cols-1)*offsets;
    int rows = src.rows;

    //像素点数组并全部初始化为0
    int pixel[9] = {0};
    string Med_Filter_title = "Median_Filter_Img";

    int size = (int)sizeof(pixel)/sizeof(*pixel);

    //输出图像初始化
    dst = Mat::zeros(src.size(),src.type());

    //算法实现
    //需要排序算法
    for(int row = 1;row < (rows-1);row++)
    {
        const uchar* current = src.ptr<uchar>(row);
        const uchar* previous = src.ptr<uchar>(row+1);
        const uchar* next = src.ptr<uchar>(row+1);

        //输出像素点赋值
        uchar* output = dst.ptr<uchar>(row);

        for(int col = offsets;col < cols;col++)
        {
            pixel[point_00] = previous[col-offsets];
            pixel[point_01] = previous[col];
            pixel[point_02] = previous[col+offsets];
            pixel[point_03] = current[col-offsets];
            pixel[point_04] = current[col];
            pixel[point_05] = current[col+offsets];
            pixel[point_06] = next[col-offsets];
            pixel[point_07] = next[col];
            pixel[point_08] = next[col+offsets];

            //排序
            filter.bubble_sort(pixel,size);
            //输出
            output[col] = pixel[point_04];
        }
    }

    //显示图像
    namedWindow(Med_Filter_title,WINDOW_AUTOSIZE);
    imshow(Med_Filter_title,dst);
}

/*********************************
 * 函数功能：冒泡排序
 * 返回值：NOON
 * data:2020/6/18
 * 入口参数：需要排序的数组，数组大小
 * 实现目标：任意大小数组的排序
 * Author：shijin
*********************************/
void Filter::bubble_sort(int arr[],int len)
{
    int i,j,temp;
    for(i = 0;i < len-1;i++)
    {
        for(j = 0;j < len-1-i;j++)
        {
            //如果前一个大于后一个
            if(arr[j] > arr[j+1])
            {
                //交换
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

//膨胀算法
void Filter::Dilate(Mat src,Mat dst)
{
    int offsets = src.channels();
    int cols = (src.cols-1)*offsets;
    int rows = src.rows;

    //像素点数组并全部初始化为0
    int pixel[9] = {0};
    string Dilate_Title = "Dilate_Title_Img";

    int size = (int)sizeof(pixel)/sizeof(*pixel);

    //输出图像初始化
    dst = Mat::zeros(src.size(),src.type());

    //算法实现
    //需要排序算法
    for(int row = 1;row < (rows-1);row++)
    {
        const uchar* current = src.ptr<uchar>(row);
        const uchar* previous = src.ptr<uchar>(row+1);
        const uchar* next = src.ptr<uchar>(row+1);

        //输出像素点赋值
        uchar* output = dst.ptr<uchar>(row);

        for(int col = offsets;col < cols;col++)
        {
            pixel[point_00] = previous[col-offsets];
            pixel[point_01] = previous[col];
            pixel[point_02] = previous[col+offsets];
            pixel[point_03] = current[col-offsets];
            pixel[point_04] = current[col];
            pixel[point_05] = current[col+offsets];
            pixel[point_06] = next[col-offsets];
            pixel[point_07] = next[col];
            pixel[point_08] = next[col+offsets];

            //排序
            filter.bubble_sort(pixel,size);
            //输出
            output[col] = pixel[point_08];
        }
    }

    //显示图像
    namedWindow(Dilate_Title,WINDOW_AUTOSIZE);
    imshow(Dilate_Title,dst);
}

//腐蚀算法
void Filter::Erosion(Mat src,Mat dst)
{
    int offsets = src.channels();
    int cols = (src.cols-1)*offsets;
    int rows = src.rows;

    //像素点数组并全部初始化为0
    int pixel[9] = {0};
    string Erosion_Title = "Erosion_Title_Img";

    int size = (int)sizeof(pixel)/sizeof(*pixel);

    //输出图像初始化
    dst = Mat::zeros(src.size(),src.type());

    //算法实现
    //需要排序算法
    for(int row = 1;row < (rows-1);row++)
    {
        const uchar* current = src.ptr<uchar>(row);
        const uchar* previous = src.ptr<uchar>(row+1);
        const uchar* next = src.ptr<uchar>(row+1);

        //输出像素点赋值
        uchar* output = dst.ptr<uchar>(row);

        for(int col = offsets;col < cols;col++)
        {
            pixel[point_00] = previous[col-offsets];
            pixel[point_01] = previous[col];
            pixel[point_02] = previous[col+offsets];
            pixel[point_03] = current[col-offsets];
            pixel[point_04] = current[col];
            pixel[point_05] = current[col+offsets];
            pixel[point_06] = next[col-offsets];
            pixel[point_07] = next[col];
            pixel[point_08] = next[col+offsets];

            //排序
            filter.bubble_sort(pixel,size);
            //输出
            output[col] = pixel[point_00];
        }
    }

    //显示图像
    namedWindow(Erosion_Title,WINDOW_AUTOSIZE);
    imshow(Erosion_Title,dst);
}


